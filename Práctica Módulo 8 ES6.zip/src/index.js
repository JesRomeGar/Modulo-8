import * as clientListBusiness from "./client-list-business";

window.onload = function () {
  clientListBusiness.printClientsAccounts();
};
